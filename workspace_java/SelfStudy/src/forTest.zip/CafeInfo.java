package forTest;

public class CafeInfo {
	int price;
	String menu;
}
